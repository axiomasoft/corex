<?php
require getenv('COREX_P3_SDK_AUTOLOAD');
require __DIR__.'/test-functions.php';
require __DIR__.'/RetryOnTestException.php';
require __DIR__.'/FilesystemAdapterTestCase.php';
require __DIR__.'/S3ClientStub.php';
require __DIR__.'/AwsS3V3AdapterTest.php';
$c=json_decode(file_get_contents(getenv('COREX_P3_STORAGE_CONFIG')),true,flags:JSON_THROW_ON_ERROR);
putenv('FLYSYSTEM_AWS_S3_BUCKET='.$c['bucket']);
$r=new ReflectionProperty(League\Flysystem\AwsS3V3\AwsS3V3AdapterTest::class,'s3Client');
$r->setValue(null,new Aws\S3\S3Client(['version'=>'latest','region'=>$c['region'],'endpoint'=>$c['endpoint'],'use_path_style_endpoint'=>true,'credentials'=>['key'=>$c['key'],'secret'=>$c['secret']]]));
