<?php

return [

    'single' => [

        'label' => 'স্থায়ীভাবে মুছে ফেলুন',

        'modal' => [

            'heading' => ':label স্থায়ীভাবে মুছে ফেলুন',

            'actions' => [

                'delete' => [
                    'label' => 'মুছে ফেলুন',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'মুছে ফেলা হয়েছে',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'নির্বাচিতগুলো স্থায়ীভাবে মুছে ফেলুন',

        'modal' => [

            'heading' => 'নির্বাচিত :label স্থায়ীভাবে মুছে ফেলুন',

            'actions' => [

                'delete' => [
                    'label' => 'মুছে ফেলুন',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'মুছে ফেলা হয়েছে',
            ],

            'deleted_partial' => [
                'title' => ':total এর মধ্যে :countটি স্থায়ীভাবে মুছে ফেলা হয়েছে',
                'missing_authorization_failure_message' => 'আপনার :countটি স্থায়ীভাবে মুছে ফেলার অনুমতি নেই।',
                'missing_processing_failure_message' => ':countটি স্থায়ীভাবে মুছে ফেলা সম্ভব হয়নি।',
            ],

            'deleted_none' => [
                'title' => 'স্থায়ীভাবে মুছে ফেলতে ব্যর্থ হয়েছে',
                'missing_authorization_failure_message' => 'আপনার :countটি স্থায়ীভাবে মুছে ফেলার অনুমতি নেই।',
                'missing_processing_failure_message' => ':countটি স্থায়ীভাবে মুছে ফেলা সম্ভব হয়নি।',
            ],

        ],

    ],

];
