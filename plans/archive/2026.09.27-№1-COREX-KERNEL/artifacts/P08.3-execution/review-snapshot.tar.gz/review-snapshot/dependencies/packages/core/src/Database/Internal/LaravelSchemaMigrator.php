<?php

declare(strict_types=1);

namespace CoreX\Database\Internal;

use CoreX\Database\Contracts\SchemaMigrator;
use CoreX\Database\Contracts\SchemaSets;
use CoreX\Database\Data\SchemaSet;
use CoreX\Database\Data\SchemaSetStatus;
use CoreX\Database\Enums\SchemaScope;
use CoreX\Database\Exceptions\SchemaSetException;
use Illuminate\Database\DatabaseManager;
use Illuminate\Database\Migrations\Migrator;
use InvalidArgumentException;

/** @internal */
final readonly class LaravelSchemaMigrator implements SchemaMigrator
{
    public function __construct(private SchemaSets $sets, private Migrator $migrator, private DatabaseManager $db) {}

    public function migrate(SchemaScope $scope, ?string $connection = null, bool $includeModules = false): array
    {
        if ($scope === SchemaScope::Dedicated && $connection !== null) {
            throw new InvalidArgumentException('Dedicated schema sets run on their own connections.');
        }

        return $this->run($this->sets->forScope($scope, $includeModules), $connection);
    }

    public function migrateSets(array $ids, ?string $connection = null): array
    {
        $sets = array_map($this->sets->get(...), array_values(array_unique($ids)));
        $scopes = array_unique(array_map(static fn (SchemaSet $set): string => $set->scope->value, $sets));

        if (count($scopes) > 1) {
            throw new InvalidArgumentException('Explicit schema sets must belong to one scope.');
        }

        return $this->run($sets, $connection);
    }

    public function status(SchemaScope $scope, ?string $connection = null): array
    {
        if ($scope === SchemaScope::Dedicated && $connection !== null) {
            throw new InvalidArgumentException('Dedicated schema sets run on their own connections.');
        }
        $sets = $this->sets->forScope($scope, includeModules: true);
        $groups = $this->groups($sets, $connection);
        $known = array_keys($this->migrator->getMigrationFiles(array_map(static fn (SchemaSet $set): string => $set->path, $this->sets->all())));
        $result = [];
        foreach ($groups as $name => $group) {
            $this->migrator->usingConnection($name, function () use ($group, $known, &$result): void {
                $repository = $this->migrator->getRepository();
                $ran = $repository->repositoryExists() ? $repository->getRan() : [];
                foreach ($group as $set) {
                    $files = array_keys($this->migrator->getMigrationFiles([$set->path]));
                    // Baseline names reserve a two-digit package prefix in the sequence component.
                    $prefixes = [];
                    foreach ($files as $file) {
                        if (preg_match('/^2026_10_01_(\d{2})\d{4}_/', $file, $match) === 1) {
                            $prefixes[] = $match[1];
                        }
                    }
                    $unknown = array_values(array_filter(array_diff($ran, $known), static function (string $file) use ($prefixes): bool {
                        return preg_match('/^\d{4}_\d{2}_\d{2}_(\d{2})\d{4}_/', $file, $match) === 1 && in_array($match[1], $prefixes, true);
                    }));
                    $result[] = new SchemaSetStatus($set, array_values(array_intersect($files, $ran)), array_values(array_diff($files, $ran)), $unknown);
                }
            });
        }
        usort($result, static fn (SchemaSetStatus $a, SchemaSetStatus $b): int => strcmp($a->set->id(), $b->set->id()));

        return $result;
    }

    /**
     * Validate the entire selection before touching any migration repository.
     *
     * @param  list<SchemaSet>  $sets
     * @return array<string, list<SchemaSet>>
     */
    private function groups(array $sets, ?string $connection): array
    {
        $groups = [];
        foreach ($sets as $set) {
            if ($set->scope === SchemaScope::Dedicated && $connection !== null) {
                throw new InvalidArgumentException('Dedicated schema sets run on their own connections.');
            }
            $name = $set->connection ?? $connection ?? $this->db->getDefaultConnection();
            $driver = $this->db->connection($name)->getDriverName();

            if (! in_array($driver, $set->drivers, true)) {
                throw SchemaSetException::unsupportedDriver($set->id(), $driver);
            }
            $groups[$name][] = $set;
        }

        return $groups;
    }

    /**
     * @param  list<SchemaSet>  $sets
     * @return list<string>
     */
    private function run(array $sets, ?string $connection): array
    {
        $groups = $this->groups($sets, $connection);
        $ran = [];
        foreach ($groups as $name => $group) {
            $ran = [...$ran, ...$this->migrator->usingConnection($name, function () use ($group): array {
                $repository = $this->migrator->getRepository();

                if (! $repository->repositoryExists()) {
                    $repository->createRepository();
                }
                $before = $repository->getRan();
                $this->migrator->run(array_map(static fn (SchemaSet $set): string => $set->path, $group));

                return array_values(array_diff($repository->getRan(), $before));
            })];
        }

        return $ran;
    }
}
