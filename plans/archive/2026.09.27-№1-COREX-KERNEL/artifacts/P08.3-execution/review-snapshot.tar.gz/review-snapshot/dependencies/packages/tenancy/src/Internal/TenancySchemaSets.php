<?php

declare(strict_types=1);

namespace CoreX\Tenancy\Internal;

use CoreX\Database\Contracts\SchemaSetProvider;
use CoreX\Database\Data\SchemaSet;
use CoreX\Database\Enums\SchemaScope;

/** @internal */
final readonly class TenancySchemaSets implements SchemaSetProvider
{
    public function sets(): array
    {
        $root = dirname(__DIR__, 2).'/database/migrations';

        return [
            new SchemaSet(package: 'axiomasoft/corex-tenancy', name: 'root', scope: SchemaScope::Central, path: $root.'/root', version: 1),
            new SchemaSet(package: 'axiomasoft/corex-tenancy', name: 'tenant', scope: SchemaScope::Tenant, path: $root.'/tenant', version: 1),
        ];
    }
}
